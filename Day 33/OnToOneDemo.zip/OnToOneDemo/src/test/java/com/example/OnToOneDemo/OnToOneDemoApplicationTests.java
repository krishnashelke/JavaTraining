package com.example.OnToOneDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnToOneDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
