package com.example.AsignLogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AsignLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
