package com.example.WebApplication_Link;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebApplicationLinkApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebApplicationLinkApplication.class, args);
	}

}
