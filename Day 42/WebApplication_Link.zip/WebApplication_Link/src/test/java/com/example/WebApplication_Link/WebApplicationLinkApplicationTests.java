package com.example.WebApplication_Link;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebApplicationLinkApplicationTests {

	@Test
	void contextLoads() {
	}

}
