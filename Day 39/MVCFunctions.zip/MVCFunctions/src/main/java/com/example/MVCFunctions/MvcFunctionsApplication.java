package com.example.MVCFunctions;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvcFunctionsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MvcFunctionsApplication.class, args);
	}

}
