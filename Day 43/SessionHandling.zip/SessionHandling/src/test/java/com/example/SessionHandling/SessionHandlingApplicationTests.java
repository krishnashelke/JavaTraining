package com.example.SessionHandling;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SessionHandlingApplicationTests {

	@Test
	void contextLoads() {
	}

}
