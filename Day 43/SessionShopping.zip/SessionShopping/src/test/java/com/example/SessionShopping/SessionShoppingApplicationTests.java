package com.example.SessionShopping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SessionShoppingApplicationTests {

	@Test
	void contextLoads() {
	}

}
