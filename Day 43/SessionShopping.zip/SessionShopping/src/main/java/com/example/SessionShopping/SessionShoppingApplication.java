package com.example.SessionShopping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SessionShoppingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SessionShoppingApplication.class, args);
	}

}
