package com.example.DemoSecurity1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSecurity1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
