package com.example.DemoSecurity1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoSecurity1Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoSecurity1Application.class, args);
	}

}
