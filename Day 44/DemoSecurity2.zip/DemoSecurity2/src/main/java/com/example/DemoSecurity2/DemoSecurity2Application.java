package com.example.DemoSecurity2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoSecurity2Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoSecurity2Application.class, args);
	}

}
