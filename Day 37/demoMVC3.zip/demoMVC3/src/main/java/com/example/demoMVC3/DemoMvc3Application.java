package com.example.demoMVC3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoMvc3Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoMvc3Application.class, args);
	}

}
